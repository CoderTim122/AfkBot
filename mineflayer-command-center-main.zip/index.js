var config = require('./config.json');
var sessionManager = require('./mineflayer.js');

sessionManager.start()